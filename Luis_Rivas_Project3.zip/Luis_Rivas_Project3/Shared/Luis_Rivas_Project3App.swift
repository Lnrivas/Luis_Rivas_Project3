//
//  Luis_Rivas_Project3App.swift
//  Shared
//
//  Created by Luis Rivas on 4/12/22.
//

import SwiftUI

@main
struct Luis_Rivas_Project3App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
