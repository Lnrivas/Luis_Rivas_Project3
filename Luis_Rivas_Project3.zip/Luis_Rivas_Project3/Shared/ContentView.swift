//
//  ContentView.swift
//  Shared
//
//  Created by Luis Rivas on 4/12/22.
//

import SwiftUI

struct ContentView: View {
    @State private var selection = 1
    @State private var rotation: Double = 0
    @State private var isSpinning1: Bool = true
    @State private var isSpinning2: Bool = true
    @State private var isSpinning3: Bool = true
    let color = Gradient(colors: [Color.red, Color.blue, Color.pink, Color.yellow])
    var body: some View {
        TabView(selection: $selection) {
            ZStack {
                MyShape()
                    .fill(RadialGradient (gradient: color, center: .center, startRadius: CGFloat(0), endRadius: CGFloat(300)))
                    .background(LinearGradient(gradient: Gradient(colors: [Color.black, Color.white]), startPoint: .topLeading, endPoint: .bottomTrailing))
                    .frame(width: 360, height: 350)
                    .rotationEffect(.degrees(isSpinning1 ? 0 : 360))
                    .animation(Animation.linear(duration: 5))
                    .onTapGesture {
                        isSpinning1 = !isSpinning1
                    }
            }
            .tabItem {
                Image(systemName: "1.circle")
                Text("Screen One")
            }.tag(1)
            ZStack {
                MyShape()
                    .fill(LinearGradient(gradient: color, startPoint: .topLeading, endPoint: .bottomTrailing))
                    .background(LinearGradient(gradient: Gradient(colors: [Color.brown, Color.yellow]), startPoint: .topLeading, endPoint: .bottomTrailing))
                    .frame(width: 360, height: 350)
                    .rotationEffect(.degrees(isSpinning2 ? 0 : 360))
                    .animation(Animation.linear(duration: 5))
                    .onTapGesture {
                        isSpinning2 = !isSpinning2
                    }
            }
            .tabItem {
                Image(systemName: "2.circle")
                Text("Screen Two")
            }.tag(2)
            ZStack {
                MyShape()
                    .fill(AngularGradient(gradient: color, center: .center))
                    .background(LinearGradient(gradient: Gradient(colors: [Color.blue, Color.green]), startPoint: .topLeading, endPoint: .bottomTrailing))
                    .frame(width: 360, height: 350)
                    .rotationEffect(.degrees(isSpinning3 ? 0 : 360))
                    .animation(Animation.linear(duration: 5))
                    .onTapGesture {
                        isSpinning3 = !isSpinning3
                    }
            }
            .tabItem {
                Image(systemName: "3.circle")
                Text("Screen Three")
            }.tag(3)
        }.font(.largeTitle)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct MyShape: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: CGPoint(x: rect.minX, y: rect.minY))
        path.addQuadCurve(to: CGPoint(x: rect.minX, y: rect.maxY),
                          control: CGPoint(x: rect.midX, y: rect.midY))
        path.addLine(to: CGPoint(x: rect.minX, y: rect.maxY))
        path.addLine(to: CGPoint(x: rect.maxX, y: rect.maxY))
        path.closeSubpath()
        return path
    }
}
